package com.example.text0511application;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.Loader;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Observable;

public class MainActivity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    private ImageView mIv1;
    private Button mbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mIv1 = findViewById(R.id.iv_1);
        mbtn = findViewById(R.id.btn);
//        Glide.with(this).load("https://t7.baidu.com/it/u=1595072465,3644073269&fm=193&f=GIF").into(mIv1);
        mbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final Animation alpha= AnimationUtils.loadAnimation(this, R.anim.anim_alpha);
//                alpha.setRepeatCount(Animation.INFINITE);//循环显示
//                mIv1.startAnimation(alpha);
                final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
                dialog.setTitle("提示信息\n     正在下载中，请稍候···");
//                dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                dialog.show();
                new Thread() {
                    public void run() {
                        SystemClock.sleep(1400);
                       if(dialog!=null)
                        dialog.dismiss();
                        //可以在里面添加功能，比如加载完后跳转界面
                    };
                }.start();

                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        //从网络上获取图片
                        final Bitmap bitmap=getPicture("https://t7.baidu.com/it/u=1595072465,3644073269&fm=193&f=GIF");
                        try {
                            Thread.sleep(1000);//线程休眠两秒钟
                        } catch (InterruptedException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
//                        alpha.setRepeatCount(0);//循环显示
                        //发送一个Runnable对象
                        mbtn.post(new Runnable(){
                            @Override
                            public void run() {
                                mIv1.setImageBitmap(bitmap);//在ImageView中显示从网络上获取到的图片
                            }

                        });

                    }
                }).start();//开启线程
            }
                                    /*
                                     * 功能:根据网址获取图片对应的Bitmap对象
                                     * @param path
                                     * @return Bitmap
                                     * */
                                    public Bitmap getPicture(String path){
                                        Bitmap bm=null;
                                        URL url;
                                        try {
                                            url = new URL(path);//创建URL对象
                                            URLConnection conn=url.openConnection();//获取URL对象对应的连接
                                            conn.connect();//打开连接
                                            InputStream is=conn.getInputStream();//获取输入流对象
                                            bm=BitmapFactory.decodeStream(is);//根据输入流对象创建Bitmap对象
                                        } catch (MalformedURLException e1) {
                                            e1.printStackTrace();//输出异常信息
                                        }catch (IOException e) {
                                            e.printStackTrace();//输出异常信息
                                        }
                                        return bm;
                                    }
        });


    }
}









