package com.cxd.chatview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class personal_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_);
    }
}
