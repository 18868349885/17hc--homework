package com.cxd.chatview;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button mchat,mfriends,mpersonal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mchat=findViewById(R.id.chat);
        mchat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, chat_Activity.class);
                startActivity(intent);
            }
        });
        mfriends=findViewById(R.id.friends);
        mfriends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,friend_Activity.class);
                startActivity(intent);
            }
        });
        mpersonal=findViewById(R.id.personal);
        mpersonal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,personal_Activity.class);
                startActivity(intent);}
        });

    }
}

