package com.cxd.chatview;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.cxd.chatview.moudle.ChatView;


public class chat_Activity extends AppCompatActivity {
    private Button mcb3;

    ChatView firstView,thirdView ;
    Activity context ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_);

        context = this ;
        mcb3=findViewById(R.id.cb3);
        mcb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(chat_Activity.this,personal_Activity.class);
                startActivity(intent);
            }
        });

        firstView = findViewById(R.id.firstView);
        thirdView = findViewById(R.id.thirdView);
        firstView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"触发点击事件",Toast.LENGTH_SHORT).show();
            }
        });

        thirdView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(context,"触发长按事件",Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }
}
