package com.example.shiyan40509;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button mbtn1;
    private Button send;
//    private EditText edContent;
//    private EditText edPhone;

    private static final int SEND_SMS = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mbtn1 = findViewById(R.id.btn1);
        send=findViewById(R.id.button);
//        edContent= (EditText) findViewById(R.id.ed_Content);
//        edPhone = (EditText) findViewById(R.id.ed_Phone);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("smsto:13027208073");
                Intent intent = new Intent(Intent.ACTION_SENDTO,uri);
                intent.putExtra("sms_body","呵呵，妹妹说笑了！");
                startActivity(intent);

            }
        });




        mbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = "我是传递的信息";
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("extra_data", data);
//                startActivity(intent);
                startActivityForResult(intent, 1);
            }

        });

    }

//    @Override
//    protected void onActivityForResult(int requestCode.int resultCode, Intent data) {
//        switch (requestCode) {
//            case 1:
//                if (resultCode == RESULT_OK) {
//                    String returnedData = data.getStringExtra("data_return");
//                    Toast.makeText(MainActivity.this, "returnedData", Toast.LENGTH_LONG).show();
//                }
//                break;
//            default:
//        }
//    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    String returnedData = data.getStringExtra("data_return");
//                    Toast.makeText(MainActivity.this, "returnedData", Toast.LENGTH_LONG).show();
//                    Toast.makeText(MainActivity.this,data.getExtras().getString("data_return"),Toast.LENGTH_LONG).show();

                    Log.d("MainActivity",returnedData);
                }
                break;
            default:
        }
    }

//    private void requestPermission() {
//        //判断Android版本是否大于23
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            int checkCallPhonePermission = ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);
//            if (checkCallPhonePermission != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SEND_SMS);
//                return;
//            } else {
//                sendSMSS();
//                //已有权限
//            }
//        } else {
//            //API 版本在23以下
//        }
//    }
//
//    /**
//     * 注册权限申请回调
//     *
//     * @param requestCode  申请码
//     * @param permissions  申请的权限
//     * @param grantResults 结果
//     */
//    @Override
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//        switch (requestCode) {
//            case SEND_SMS:
//                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    sendSMSS();
//                } else {
//                    // Permission Denied
//                    Toast.makeText(MainActivity.this, "CALL_PHONE Denied", Toast.LENGTH_SHORT).show();
//                }
//                break;
//            default:
//                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        }
//    }
//
//    //发送短信
//    private void sendSMSS() {
//
//        String content = edContent.getText().toString().trim();
//        String phone = edPhone.getText().toString().trim();
//        if (!StringUtil.isEmpty(content) && !StringUtil.isEmpty(phone)) {
//            SmsManager manager = SmsManager.getDefault();
//            ArrayList<String> strings = manager.divideMessage(content);
//            for (int i = 0; i < strings.size(); i++) {
//                manager.sendTextMessage(phone, null, content, null, null);
//            }
//            Toast.makeText(MainActivity.this, "发送成功", Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(this, "手机号或内容不能为空", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//    }



}
